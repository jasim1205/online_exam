 <ul>
                        {{-- <li class="menu-title">
                            <span>Main</span>
                        </li> --}}
                        <li>
                            <a href="{{route('student_dashboard')}}"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
                        </li>
                        <li>
                            <a href="{{route('profile')}}"><i class="la la-user"></i> <span> Profile</span> <span class="menu-arrow"></span></a>
                        </li>
                        <li class="">
                            <a href="{{route('student.exam')}}"><i class="la la-cube"></i> <span> Exam List</span> <span class="menu-arrow"></span></a>
                        </li>
                        <li>
                            <a href="{{route('logOut')}}"><i class="la la-lock"></i> <span>Logout</span></a>
                        </li>
                        
                    </ul>